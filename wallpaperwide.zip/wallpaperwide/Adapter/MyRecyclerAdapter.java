package nr.king.vbk.wallpaperwide.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.List;

import nr.king.vbk.wallpaperwide.Common.Common;
import nr.king.vbk.wallpaperwide.Database.Recents;
import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.ListActivity;
import nr.king.vbk.wallpaperwide.Model.WallpaperItem;
import nr.king.vbk.wallpaperwide.R;
import nr.king.vbk.wallpaperwide.ViewHolder.ListWallpaperViewHolder;
import nr.king.vbk.wallpaperwide.view_wall;

/**
 * Created by vbk on 10/3/18.
 */

public class MyRecyclerAdapter extends RecyclerView.Adapter<ListWallpaperViewHolder> {
    private Context context;
    private List<Recents>recents;

    public MyRecyclerAdapter(Context context, List <Recents> recents) {
        this.context = context;
        this.recents = recents;
    }

    @NonNull
    @Override
    public ListWallpaperViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View View= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.lay_cat,parent,false);
        int height=parent.getMeasuredHeight()/2;
        View.setMinimumHeight(height);

        return new ListWallpaperViewHolder(View);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListWallpaperViewHolder holder, final int position) {
        Picasso.with(context)
                .load(recents.get(position).getImage())
                .networkPolicy(NetworkPolicy.OFFLINE)
                .into(holder.imageView, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError() {
                        Picasso.with(context)
                                .load(recents.get(position).getImage())
                                .error(R.drawable.ic_terrain_black_24dp)
                                .into(holder.imageView, new Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onError() {
                                        Log.d("ERROR_VBK","Could Not Load");


                                    }
                                });


                    }
                });
        holder.setItemCLickListener(new ItemCLickListener() {
            @Override
            public void onClick(View view, int position) {

                Intent intent=new Intent(context,view_wall.class);
                WallpaperItem wallpaperItem=new WallpaperItem();
                wallpaperItem.setMenuId(recents.get(position).getMenuId());
                wallpaperItem.setImage(recents.get(position).getImage());
                Common.select_background=wallpaperItem;
                context.startActivity(intent);

                // Toast.makeText(ListActivity.this, "Item Clicked!!!", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
