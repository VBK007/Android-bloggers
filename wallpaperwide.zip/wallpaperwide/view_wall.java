package nr.king.vbk.wallpaperwide;

import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.Sharer;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;
import com.github.clans.fab.FloatingActionMenu;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;

import java.util.UUID;

import dmax.dialog.SpotsDialog;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import nr.king.vbk.wallpaperwide.Common.Common;
import nr.king.vbk.wallpaperwide.Database.DataSource.RecentRepository;
import nr.king.vbk.wallpaperwide.Database.LocalDB.LOcalDAtabase;
import nr.king.vbk.wallpaperwide.Database.LocalDB.RecentDataSource;
import nr.king.vbk.wallpaperwide.Database.Recents;
import nr.king.vbk.wallpaperwide.Model.WallpaperItem;


public class view_wall extends AppCompatActivity {

    CollapsingToolbarLayout collapsingToolbarLayout;
    FloatingActionButton floatingActionButton,fab;
    ImageView imageView;
  CoordinatorLayout rootLayout;
CompositeDisposable compositeDisposable;
RecentRepository recentRepository;
FloatingActionMenu mainFloating;
com.github.clans.fab.FloatingActionButton floatingActionButtonn;
CallbackManager callbackManager;
ShareDialog shareDialog;


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
       if(requestCode!=0){

            if (grantResults.length>0&& grantResults[0]== PackageManager.PERMISSION_GRANTED) {

                AlertDialog dialog=new SpotsDialog(view_wall.this);

                dialog.show();
                dialog.setMessage("Please Waiting...");

                String filename= UUID.randomUUID().toString()+".png";
                Picasso.with(getBaseContext())
                        .load(Common.select_background.getImage())
                        .into(new SaveImageUrl(getBaseContext(),
                                dialog,
                                getApplicationContext().getContentResolver()
                                ,filename,
                                "VBK Live Wallpapers"));


            }
            else {
                Toast.makeText(this, "Failed!!", Toast.LENGTH_SHORT).show();
            }


        }

    }

    private Target target=new Target() {
        @Override
        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
            WallpaperManager wallpaperManager=WallpaperManager.getInstance(getApplicationContext());
            try {
                wallpaperManager.setBitmap(bitmap);
//                Toast.makeText(this, "Wallpaper was Set!!", Toast.LENGTH_SHORT).show();

                Snackbar.make(rootLayout,"Wallpaper was Set!!",Snackbar.LENGTH_SHORT).show();

            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        @Override
        public void onBitmapFailed(Drawable errorDrawable) {

        }

        @Override
        public void onPrepareLoad(Drawable placeHolderDrawable) {

        }
    };
    private Target facebookConvertbitmap=new Target() {
        @Override
        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
            SharePhoto sharePhoto=new SharePhoto.Builder()
                    .setBitmap(bitmap)
                    .build();
            if (ShareDialog.canShow(SharePhotoContent.class)){
                SharePhotoContent content=new SharePhotoContent.Builder()
                        .addPhoto(sharePhoto)
                        .build();
                shareDialog.show(content);
            }
        }

        @Override
        public void onBitmapFailed(Drawable errorDrawable) {

        }

        @Override
        public void onPrepareLoad(Drawable placeHolderDrawable) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_wall);

        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setDisplayHomeAsUpEnabled(true);


if (getSupportActionBar()!=null)
    getSupportActionBar().setDisplayShowHomeEnabled(true);

callbackManager=CallbackManager.Factory.create();
shareDialog=new ShareDialog(this);

compositeDisposable=new CompositeDisposable();
LOcalDAtabase dAtabase=LOcalDAtabase.getInstance(this);
recentRepository=RecentRepository.getInsatance(RecentDataSource.getInstance(dAtabase.recentDOB()));


        rootLayout=(CoordinatorLayout) findViewById(R.id.rootLayout);
       collapsingToolbarLayout=(CollapsingToolbarLayout)findViewById(R.id.collapsing);

     collapsingToolbarLayout.setCollapsedTitleTextAppearance(R.style.CollapseAppBar);
     collapsingToolbarLayout.setExpandedTitleTextAppearance(R.style.ExpandedAppBar);


     collapsingToolbarLayout.setTitle(Common.CATERGORY_SELECTED);

     imageView=(ImageView)findViewById(R.id.image);

     Picasso.with(this)
             .load(Common.select_background.getImage())
             .into(imageView);

//addToRecents();
     floatingActionButton=(FloatingActionButton)findViewById(R.id.fabWallpaper);
     floatingActionButton.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {

             Picasso.with(getBaseContext())
                     .load(Common.select_background.getImage())
                     .into(target);


         }
     });

fab=(FloatingActionButton)findViewById(R.id.fabDownload);
fab.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        AlertDialog dialog=new SpotsDialog(view_wall.this);

        dialog.show();
        dialog.setMessage("Please Waiting...");

        String filename= UUID.randomUUID().toString()+".png";
        Picasso.with(getBaseContext())
                .load(Common.select_background.getImage())
                .into(new SaveImageUrl(getBaseContext(),
                        dialog,
                        getApplicationContext().getContentResolver()
                       ,filename,
                        "VBK Live Wallpapers"));






    }
});



mainFloating=(FloatingActionMenu) findViewById(R.id.menu);
floatingActionButtonn=(com.github.clans.fab.FloatingActionButton)findViewById(R.id.fb_share);
floatingActionButtonn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
   shareDialog.registerCallback(callbackManager, new FacebookCallback <Sharer.Result>() {
       @Override
       public void onSuccess(Sharer.Result result) {
           Toast.makeText(view_wall.this, "Share Succesfull!", Toast.LENGTH_SHORT).show();
       }

       @Override
       public void onCancel() {
           Toast.makeText(view_wall.this, "Share cancelled!", Toast.LENGTH_SHORT).show();
       }

       @Override
       public void onError(FacebookException error) {
           Toast.makeText(view_wall.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
       }
   });

   Picasso.with(getBaseContext())
           .load(Common.select_background.getImage())
           .into(facebookConvertbitmap);


    }
});


    }

    private void addToRecents() {

        Disposable disposable=Observable.create(new ObservableOnSubscribe <Object>() {
            @Override
            public void subscribe(ObservableEmitter <Object> e) throws Exception {
                Recents recents=new Recents(

                        Common.select_background.getImage(),
                        Common.select_background.getMenuId(),
                        String.valueOf(System.currentTimeMillis()));
                recentRepository.insertRecent(recents);
                e.onComplete();
            }
        }).observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer<Object>() {
                    @Override
                    public void accept(Object o) throws Exception {

                    }
                },new Consumer<Throwable>(){
            @Override
            public void accept(Throwable throwable) throws Exception {
                Log.e("ERROR",throwable.getMessage());
            }
        },new Action(){
            @Override
            public void run() throws Exception {

            }
        });
        compositeDisposable.add(disposable);
    }




    @Override
    protected void onDestroy() {
        Picasso.with(getBaseContext()).cancelRequest(target);
        compositeDisposable.clear();
        super.onDestroy();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        if (item.getItemId()== android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }
}
