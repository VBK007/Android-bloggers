package nr.king.vbk.wallpaperwide.Interface;

import android.view.View;

/**
 * Created by vbk on 24/2/18.
 */

public interface ItemCLickListener {

    void onClick(View view,int position);
}
