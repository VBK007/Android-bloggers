package nr.king.vbk.wallpaperwide.ViewHolder;

import android.content.ClipData;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.R;

/**
 * Created by vbk on 24/2/18.
 */

public class ListWallpaperViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    ItemCLickListener itemCLickListener;
public ImageView imageView;
public TextView textView;

    public ItemCLickListener getItemCLickListener() {
        return itemCLickListener;
    }

    public void setItemCLickListener(ItemCLickListener itemCLickListener) {
        this.itemCLickListener = itemCLickListener;
    }

    public ListWallpaperViewHolder(View itemView) {
        super(itemView);
        imageView=itemView.findViewById(R.id.image);
        itemView.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        itemCLickListener.onClick(view,getAdapterPosition());

    }
//    @Override
//    public ClipData.Item getItem(int pos) {
//        return super.getItem(getCount() - 1 - pos);

//    @Override
//    public ClipData.Item getItem(int pos) {
//        return super.getItem(getCount() - 1 - pos);
//    }
//
//    private int getCount() {
//    }


}
