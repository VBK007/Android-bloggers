package nr.king.vbk.wallpaperwide.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.R;

/**
 * Created by vbk on 24/2/18.
 */

public class CategoryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
   public TextView imageText;
    public ImageView image;
    ItemCLickListener itemCLickListener;

    public ItemCLickListener getItemCLickListener() {
        return itemCLickListener;
    }

    public void setItemCLickListener(ItemCLickListener itemCLickListener) {
        this.itemCLickListener = itemCLickListener;
    }

    public CategoryViewHolder(View itemView) {
        super(itemView);

        image=(ImageView)itemView.findViewById(R.id.image);
       imageText=(TextView)itemView.findViewById(R.id.name);

        itemView.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
       itemCLickListener.onClick(v,getAdapterPosition());
    }
}
