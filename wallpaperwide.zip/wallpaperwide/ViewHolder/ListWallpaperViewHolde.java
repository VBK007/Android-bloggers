package nr.king.vbk.wallpaperwide.ViewHolder;

import android.content.ClipData;

/**
 * Created by vbk on 28/2/18.
 */

interface ListWallpaperViewHolde {
    ClipData.Item getItem(int pos);
}
