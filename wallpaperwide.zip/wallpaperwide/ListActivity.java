package nr.king.vbk.wallpaperwide;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.UUID;

import nr.king.vbk.wallpaperwide.Common.Common;
import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.Model.CategoryItem;
import nr.king.vbk.wallpaperwide.Model.WallpaperItem;
import nr.king.vbk.wallpaperwide.ViewHolder.ListWallpaperViewHolder;

public class ListActivity extends AppCompatActivity {
Query query;
CategoryItem categoryItem;
    DatabaseReference mdatabase;
    FButton fButton,fButton1;
    Uri saveuri;
    MaterialEditText edtNew;
    StorageReference storageReference;

WallpaperItem newStudent;
FirebaseRecyclerOptions <WallpaperItem> options;
FirebaseRecyclerAdapter<WallpaperItem,ListWallpaperViewHolder> adapter;
RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

       Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
       toolbar.setTitle(Common.CATERGORY_SELECTED);
       setSupportActionBar(toolbar);
fButton=(FButton)findViewById(R.id.stuLogin);
fButton1=(FButton)findViewById(R.id.staLogin);

        storageReference = FirebaseStorage.getInstance().getReference();
      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
     getSupportActionBar().setDisplayShowHomeEnabled(true);
        edtNew=(MaterialEditText)findViewById(R.id.edtNewName);
        recyclerView=(RecyclerView)findViewById(R.id.recycler_category_list_wallpaper);
        //recyclerView.setHasFixedSize(true);
       // LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
//        mLayoutManager.setReverseLayout(true);
//        mLayoutManager.setStackFromEnd(true);
        mdatabase=FirebaseDatabase.getInstance().getReference().child("Foods");
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);

//        gridLayoutManager.setStackFromEnd(true);
//        gridLayoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(gridLayoutManager);
        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.navigation);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.action_news:
                        Toast.makeText(ListActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
break;
                    case R.id.action_explore:
                        Toast.makeText(ListActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.action_upload:
                        updateInfo();


                }






            }
        });


        loadList();

    }


    private void updateInfo() {

        AlertDialog.Builder alertDialog=new AlertDialog.Builder(this);
        alertDialog.setTitle("Upload Image!");
        alertDialog.setMessage("Please fill all the Info!!!");


        LayoutInflater inflater=LayoutInflater.from(this);
        View infl=inflater.inflate(R.layout.updateinfo,null);

      edtNew=infl.findViewById(R.id.edtNewName);


    fButton=infl.findViewById(R.id.stuLogin);
        fButton1=infl.findViewById(R.id.staLogin);

        fButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SelectImageUpload();
            }
        });

        fButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UploadedImage();




            }
        });


        alertDialog.setView(infl);

        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();

                if (newStudent != null) {

                    mdatabase.push().setValue(newStudent);

                }
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {


            }
        });

        alertDialog.show();






    }

    private void UploadedImage() {
        final ProgressDialog mDialog=new ProgressDialog(this);
        mDialog.setMessage("Uploading");
        mDialog.show();

//edtNew=(MaterialEditText)findViewById(R.id.edtNewName);

        final String titleValue=edtNew.getText().toString().trim();
        //edtNew.getText().toString().trim();

        FButton fButton=(FButton)findViewById(R.id.stuLogin);
        FButton fButton1=(FButton)findViewById(R.id.staLogin);


        String imageName= UUID.randomUUID().toString();
        final StorageReference imageFolder=storageReference.child("Image").child(saveuri.getLastPathSegment());
        imageFolder.putFile(saveuri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                    @Override
                    public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot) {
                        final Uri downloadUrl=taskSnapshot.getDownloadUrl();
                        mDialog.dismiss();
                        Toast.makeText(ListActivity.this, "UploadedCompleted!!", Toast.LENGTH_SHORT).show();
                        imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener <Uri>() {

                            @Override
                            public void onSuccess(final Uri uri) {
                                mdatabase.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot dataSnapshot) {

//                                        newStudent=new Food(edtNew.getText().toString(),uri.toString());

                                        newStudent=new WallpaperItem();
                                        newStudent.setName(edtNew.getText().toString());
                                        newStudent.setImage(uri.toString());
                                        newStudent.setMenuId(Common.CATERGORY_ID_SELECTED);

                                    }

                                    @Override
                                    public void onCancelled(DatabaseError databaseError) {

                                    }
                                });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                mDialog.dismiss();
                                Toast.makeText(ListActivity.this, "Failed Retry!!!!", Toast.LENGTH_SHORT).show();
                            }
                        });



                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                mDialog.setMessage("Uploaded" + progress + "%");


            }
        });








    }

    private void SelectImageUpload() {


        Intent intent=new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent,"SelectPicture"), Common.PICK_IMAGE_REQUEST);





    }


    private void loadList() {

        query= FirebaseDatabase.getInstance().getReference(Common.STR_WALLPAPER)
                .orderByChild("menuId").equalTo(Common.CATERGORY_ID_SELECTED);

        options=new FirebaseRecyclerOptions.Builder<WallpaperItem>()
                .setQuery(query,WallpaperItem.class)
                .build();


        adapter=new FirebaseRecyclerAdapter <WallpaperItem, ListWallpaperViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final ListWallpaperViewHolder holder, int position, @NonNull final WallpaperItem model) {

                Picasso.with(getBaseContext())
                        .load(model.getImage())
                        .networkPolicy(NetworkPolicy.OFFLINE)
                        .into(holder.imageView, new Callback() {
                            @Override
                            public void onSuccess() {

                            }

                            @Override
                            public void onError() {
                                Picasso.with(getBaseContext())
                                        .load(model.getImage())
                                        .error(R.drawable.ic_terrain_black_24dp)
                                        .into(holder.imageView, new Callback() {
                                            @Override
                                            public void onSuccess() {

                                            }

                                            @Override
                                            public void onError() {
                                                Log.d("ERROR_VBK","Could Not Load");


                                            }
                                        });


                            }
                        });
                holder.setItemCLickListener(new ItemCLickListener() {
                    @Override
                    public void onClick(View view, int position) {

                        Intent intent=new Intent(ListActivity.this,view_wall.class);
                        Common.select_background=model;
                        Common.CATERGORY_SELECTED=model.getName();
                        startActivity(intent);

                        // Toast.makeText(ListActivity.this, "Item Clicked!!!", Toast.LENGTH_SHORT).show();
                    }
                });

            }

            @Override
            public ListWallpaperViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
               View itemView= LayoutInflater.from(parent.getContext())
                       .inflate(R.layout.wall_list,parent,false);
               int height=parent.getMeasuredHeight()/2;
               itemView.setMinimumHeight(height);


                return new ListWallpaperViewHolder(itemView);
            }
        };

        adapter.startListening();
        recyclerView.setAdapter(adapter);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Common.PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {


            saveuri = data.getData();
            saveuri = data.getData();
            fButton.setText("ImageSelected!!");


        }


    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adapter!=null)
            adapter.startListening();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter!=null)
            adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adapter!=null)
            adapter.startListening();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId()== android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);

    }
}
