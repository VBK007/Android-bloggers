package nr.king.vbk.wallpaperwide.Database.LocalDB;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import io.reactivex.Flowable;
import nr.king.vbk.wallpaperwide.Database.Recents;

/**
 * Created by vbk on 10/3/18.
 */
@Dao
public interface RecentDOB {
@Query("SELECT * FROM recents ORDER BY saveTime DESC LIMIT 10")

    Flowable<List<Recents>> getAllRecent();
@Insert

    void insertRecent(Recents...recents);

@Update
    void updateRecent(Recents...recents);

@Delete
    void deleteRecent(Recents...recents);

@Query("DELETE FROM recents")
    void deleteAllRecents();




}
