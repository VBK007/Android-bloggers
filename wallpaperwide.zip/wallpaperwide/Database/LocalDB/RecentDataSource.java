package nr.king.vbk.wallpaperwide.Database.LocalDB;



import java.util.List;

import io.reactivex.Flowable;
import nr.king.vbk.wallpaperwide.Database.DataSource.IrecentDataSources;
import nr.king.vbk.wallpaperwide.Database.Recents;

/**
 * Created by vbk on 10/3/18.
 */

public class RecentDataSource implements IrecentDataSources {
 private RecentDOB recentDOB;
 private static RecentDataSource instance;


    public RecentDataSource(RecentDOB recentDOB) {
        this.recentDOB = recentDOB;
    }

    public static RecentDataSource getInstance(RecentDOB recentDOB){
        if (instance==null)
            instance=new RecentDataSource(recentDOB);

            return instance;


    }


    @Override
    public Flowable<List<Recents>> getAllRecent() {
        return recentDOB.getAllRecent();
    }

    @Override
    public void insertRecent(Recents... recents) {
recentDOB.insertRecent(recents);
    }

    @Override
    public void updateRecent(Recents... recents) {

        recentDOB.updateRecent(recents);

    }

    @Override
    public void deleteRecent(Recents... recents) {

        recentDOB.deleteRecent(recents);
    }

    @Override
    public void deleteAllRecents() {
recentDOB.deleteAllRecents();
    }
}
