package nr.king.vbk.wallpaperwide.Database.LocalDB;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import java.time.LocalDateTime;

import nr.king.vbk.wallpaperwide.Database.Recents;

import static nr.king.vbk.wallpaperwide.Database.LocalDB.LOcalDAtabase.DATABASE_VERSION;

/**
 * Created by vbk on 10/3/18.
 */

@Database(entities = Recents.class,version =DATABASE_VERSION)

public abstract class LOcalDAtabase extends RoomDatabase {

    public static final int DATABASE_VERSION=1;
    public static final String DATABASE_NAME="VBKWalllpaper";

    public abstract RecentDOB recentDOB();

    private static LOcalDAtabase instance;

    public static LOcalDAtabase getInstance(Context context)
    {

        if (instance ==null){

           instance= Room.databaseBuilder(context,LOcalDAtabase.class,DATABASE_NAME)
                   .fallbackToDestructiveMigration()
                   .build();



        }
        return instance;


    }




}
