package nr.king.vbk.wallpaperwide.Database.DataSource;

import java.util.List;

import io.reactivex.Flowable;
import nr.king.vbk.wallpaperwide.Database.Recents;

/**
 * Created by vbk on 10/3/18.
 */

public interface IrecentDataSources {
    Flowable <List<Recents>> getAllRecent();
    void insertRecent(Recents...recents);
    void updateRecent(Recents...recents);
    void deleteRecent(Recents...recents);
    void deleteAllRecents();

}
