package nr.king.vbk.wallpaperwide.Database.DataSource;

import java.util.List;

import io.reactivex.Flowable;
import nr.king.vbk.wallpaperwide.Database.Recents;

/**
 * Created by vbk on 10/3/18.
 */

public class RecentRepository implements IrecentDataSources {
    private IrecentDataSources mLocalDataSource;
    private static RecentRepository insatance;

    public RecentRepository(IrecentDataSources mLocalDataSource) {
        this.mLocalDataSource = mLocalDataSource;
    }

    public static RecentRepository getInsatance(IrecentDataSources mLocalDataSource){
        if (insatance==null){
            insatance=new RecentRepository(mLocalDataSource);
        }
    return insatance;
    }




    @Override
    public Flowable<List<Recents>> getAllRecent() {
        return mLocalDataSource.getAllRecent();
    }

    @Override
    public void insertRecent(Recents... recents) {
mLocalDataSource.insertRecent(recents);
    }

    @Override
    public void updateRecent(Recents... recents) {
mLocalDataSource.updateRecent(recents);
    }

    @Override
    public void deleteRecent(Recents... recents) {
mLocalDataSource.deleteRecent(recents);
    }

    @Override
    public void deleteAllRecents() {

        mLocalDataSource.deleteAllRecents();
    }
}
