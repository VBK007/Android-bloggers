package nr.king.vbk.wallpaperwide.Database;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.support.annotation.NonNull;


/**
 * Created by vbk on 10/3/18.
 */
@Entity(tableName = "recents",primaryKeys = {"image","menuId"})
public class Recents{
    @ColumnInfo(name = "image")
    @NonNull
    private String image;
    @ColumnInfo(name = "menuId")
    @NonNull
    private String menuId;
    @ColumnInfo(name = "saveTime")
    @NonNull
     private String saveTime;


    public Recents(String image, String menuId, String saveTime) {
        this.image = image;
        this.menuId = menuId;
        this.saveTime = saveTime;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getSaveTime() {
        return saveTime;
    }

    public void setSaveTime(String saveTime) {
        this.saveTime = saveTime;
    }
}