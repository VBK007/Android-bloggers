package nr.king.vbk.wallpaperwide.Model;

/**
 * Created by vbk on 24/2/18.
 */

public class CategoryItem {
    public String image;
    public String name;


    public CategoryItem(){

    }

    public CategoryItem(String image, String name) {
        this.image = image;
        this.name = name;
    }


    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
