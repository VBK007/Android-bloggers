package nr.king.vbk.wallpaperwide.Model;

/**
 * Created by vbk on 24/2/18.
 */

public class WallpaperItem {
    public String image;
    public String name;
    public String menuId;


    public WallpaperItem(){

    }

    public WallpaperItem(String image, String name, String menuId) {
        this.image = image;
        this.name = name;
        this.menuId = menuId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
}
