package nr.king.vbk.wallpaperwide.Common;

import nr.king.vbk.wallpaperwide.Model.WallpaperItem;

/**
 * Created by vbk on 24/2/18.
 */

public class Common {

    public static final String STR_CATEGORY="Category";
    public static final int PICK_IMAGE_REQUEST = 71;
    public static final int SIGN_INREQUEST_CODE = 1001;
    public static  String CATERGORY_SELECTED;
    public static final String  STR_WALLPAPER="Foods";
    public static String CATERGORY_ID_SELECTED;


    public static WallpaperItem select_background=new WallpaperItem();
}
