package nr.king.vbk.wallpaperwide.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.UUID;

import nr.king.vbk.wallpaperwide.Common.Common;
import nr.king.vbk.wallpaperwide.FButton;
import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.ListActivity;
import nr.king.vbk.wallpaperwide.Model.CategoryItem;
import nr.king.vbk.wallpaperwide.Model.Food;
import nr.king.vbk.wallpaperwide.Model.WallpaperItem;
import nr.king.vbk.wallpaperwide.R;
import nr.king.vbk.wallpaperwide.ViewHolder.CategoryViewHolder;

import static android.app.Activity.RESULT_OK;

public class DailyFragment extends Fragment {
    public static DailyFragment INSTANCE = null;
    RecyclerView recyclerView;
    DatabaseReference mdatabase;
    FButton fButton,fButton1;
    Uri saveuri;
    FirebaseRecyclerOptions <CategoryItem> options;
    FirebaseRecyclerAdapter <CategoryItem, CategoryViewHolder> adapter;
    MaterialEditText edtNew;
StorageReference storageReference;
FirebaseDatabase database;
DatabaseReference mDatabase;
WallpaperItem newStudent;
    public DailyFragment() {
        database = FirebaseDatabase.getInstance();
        mdatabase = database.getReference(Common.STR_CATEGORY);
        storageReference = FirebaseStorage.getInstance().getReference();
        options = new FirebaseRecyclerOptions.Builder <CategoryItem>()
                .setQuery(mdatabase, CategoryItem.class)
                .build();

        adapter = new FirebaseRecyclerAdapter <CategoryItem, CategoryViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final CategoryViewHolder holder, int position, @NonNull final CategoryItem model) {
                Picasso.with(getActivity()).load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).into(holder
                                .image, new Callback() {
                            @Override
                            public void onSuccess() {
                                //Picasso.with(getActivity()).load(model.getImage()).error()
                            }

                            @Override
                            public void onError() {
                                Picasso.with(getActivity()).load(model.getImage()).error(R.drawable.ic_terrain_black_24dp)
                                        .into(holder.image, new Callback() {
                                            @Override
                                            public void onSuccess() {

                                            }

                                            @Override
                                            public void onError() {
                                                Log.e("ERROR VBK", "COuld not FETCH IMAGE");
                                            }
                                        });


//                               holder.setItemCLickListener(new ItemCLickListener() {
//                                    @Override
//                                    public void onClick(View view, int position) {
//
//
//                                    }
//                                });

                            }
                        }
                );


                holder.imageText.setText(model.getName());
                holder.setItemCLickListener(new ItemCLickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        Common.CATERGORY_ID_SELECTED = adapter.getRef(position).getKey();
                        Common.CATERGORY_SELECTED = model.getName();
                        Intent intent = new Intent(getActivity(), ListActivity.class);
                        startActivity(intent);
                    }
                });


            }

            @Override
            public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

                View itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.lay_cat, parent, false);
                return new CategoryViewHolder(itemView);
            }
        };


    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public static DailyFragment getInstance() {
        if (INSTANCE == null)
            INSTANCE = new DailyFragment();
        return INSTANCE;

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mDatabase = FirebaseDatabase.getInstance().getReference("Foods");
        View view = inflater.inflate(R.layout.fragment_daily, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_category);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        //gridLayoutManager.setStackFromEnd(true);
        //gridLayoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(gridLayoutManager);


        recyclerView.setLayoutManager(gridLayoutManager);
        setCategory();





















        return view;
    }

//    private void updateInfo() {
//
//        AlertDialog.Builder alertDialog=new AlertDialog.Builder(getActivity());
//        alertDialog.setTitle("Change UserProfile");
//        alertDialog.setMessage("Please fill all the Info!!!");
//
//
//        LayoutInflater inflater=LayoutInflater.from(getActivity());
//        View infl=inflater.inflate(R.layout.updateinfo,null);
//
//        final MaterialEditText edtNew=(MaterialEditText)infl.findViewById(R.id.edtNewName);
//
//
//        FButton fButton=(FButton)infl.findViewById(R.id.stuLogin);
//        FButton fButton1=(FButton)infl.findViewById(R.id.staLogin);
//
//        fButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                SelectImageUpload();
//            }
//        });
//
//        fButton1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                UploadedImage();
//
//
//
//
//            }
//        });
//
//
//        alertDialog.setView(infl);
//
//        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//                dialogInterface.dismiss();
//
//                if (newStudent != null) {
//
//                    mdatabase.push().setValue(newStudent);
//
//                }
//            }
//        });
//        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialogInterface, int i) {
//
//
//            }
//        });
//
//        alertDialog.show();
//
//
//
//
//
//
//    }
//
//    private void UploadedImage() {
//        final ProgressDialog mDialog=new ProgressDialog(getActivity());
//        mDialog.setMessage("Uploading");
//        mDialog.show();
//
//
//        final String titleValue=edtNew.getText().toString().trim();
//
//
//
//        String imageName= UUID.randomUUID().toString();
//        final StorageReference imageFolder=storageReference.child("Image"+imageName);
//        imageFolder.putFile(saveuri)
//                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//
//                    @Override
//                    public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot) {
//                        final Uri downloadUrl=taskSnapshot.getDownloadUrl();
//                        mDialog.dismiss();
//                        Toast.makeText(getActivity(), "UploadedCompleted!!", Toast.LENGTH_SHORT).show();
//                        imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener <Uri>() {
//
//                            @Override
//                            public void onSuccess(final Uri uri) {
//                                mdatabase.addValueEventListener(new ValueEventListener() {
//                                    @Override
//                                    public void onDataChange(DataSnapshot dataSnapshot) {
//
////                                        newStudent=new Food(edtNew.getText().toString(),uri.toString());
//
//                                        newStudent=new WallpaperItem();
//                                        newStudent.setName(edtNew.getText().toString());
//                                        newStudent.setImage(uri.toString());
//                                        newStudent.setMenuId(Common.STR_CATEGORY);
//                                    }
//
//                                    @Override
//                                    public void onCancelled(DatabaseError databaseError) {
//
//                                    }
//                                });
//                            }
//                        }).addOnFailureListener(new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                mDialog.dismiss();
//                                Toast.makeText(getActivity(), "Failed Retry!!!!", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//
//
//
//                    }
//                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
//            @Override
//            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
//                double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
//                mDialog.setMessage("Uploaded" + progress + "%");
//
//
//            }
//        });
//
//
//
//
//
//
//
//
//    }
//
//    private void SelectImageUpload() {
//
//
//        Intent intent=new Intent();
//        intent.setAction(Intent.ACTION_GET_CONTENT);
//        intent.setType("image/*");
//        startActivityForResult(Intent.createChooser(intent,"SelectPicture"), Common.PICK_IMAGE_REQUEST);
//
//
//
//
//
//    }
//
////    @Override
////    public void onActivityResult(int requestCode, int resultCode, Intent data) {
////        super.onActivityResult(requestCode, resultCode, data);
////
////
////
////        if (requestCode==Common.PICK_IMAGE_REQUEST && resultCode==RESULT_OK && data!=null &&data.getData()!=null)
////        {
////
////
////            saveuri=data.getData();
////            saveuri = data.getData();
////            fButton.setText("ImageSelected!!");
////
////
////
////
////        }


//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == Common.PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
//
//
//            saveuri = data.getData();
//            saveuri = data.getData();
//            fButton.setText("ImageSelected!!");
//
//
//        }
//    }

    private void setCategory() {

        adapter.startListening();
        recyclerView.setAdapter(adapter);

    }

    @Override
    public void onStart() {
        super.onStart();

        if (adapter != null) {
            adapter.startListening();
        }

    }

    @Override
    public void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }


    }

}
