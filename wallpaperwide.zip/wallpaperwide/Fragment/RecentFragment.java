package nr.king.vbk.wallpaperwide.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import nr.king.vbk.wallpaperwide.Adapter.MyRecyclerAdapter;
import nr.king.vbk.wallpaperwide.Common.Common;
import nr.king.vbk.wallpaperwide.Database.DataSource.RecentRepository;
import nr.king.vbk.wallpaperwide.Database.LocalDB.LOcalDAtabase;
import nr.king.vbk.wallpaperwide.Database.LocalDB.RecentDataSource;
import nr.king.vbk.wallpaperwide.Database.Recents;
import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.ListActivity;
import nr.king.vbk.wallpaperwide.Model.CategoryItem;
import nr.king.vbk.wallpaperwide.Model.WallpaperItem;
import nr.king.vbk.wallpaperwide.R;
import nr.king.vbk.wallpaperwide.ViewHolder.CategoryViewHolder;

@SuppressLint("ValidFragment")
public class RecentFragment extends Fragment {
    public static  RecentFragment INSTANCE=null;
    RecyclerView recyclerView;
    List<Recents> recentsList;
    Context context;
    CompositeDisposable compositeDisposable;
    RecentRepository recentRepository;
    Uri saveuri;
    FirebaseRecyclerOptions <CategoryItem> options;
    FirebaseRecyclerAdapter <CategoryItem, CategoryViewHolder> adapter;
    MaterialEditText edtNew;
    StorageReference storageReference;
    FirebaseDatabase database;
    DatabaseReference mdatabase;
    WallpaperItem newStudent;

    @SuppressLint("ValidFragment")
    public RecentFragment() {
        //
        // Required empty public constructor

        database = FirebaseDatabase.getInstance();
        mdatabase = database.getReference(Common.STR_CATEGORY);
        storageReference = FirebaseStorage.getInstance().getReference();
        options = new FirebaseRecyclerOptions.Builder <CategoryItem>()
                .setQuery(mdatabase, CategoryItem.class)
                .build();

        adapter = new FirebaseRecyclerAdapter <CategoryItem, CategoryViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final CategoryViewHolder holder, int position, @NonNull final CategoryItem model) {
                Picasso.with(getActivity()).load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).into(holder
                                .image, new Callback() {
                            @Override
                            public void onSuccess() {
                                //Picasso.with(getActivity()).load(model.getImage()).error()
                            }

                            @Override
                            public void onError() {
                                Picasso.with(getActivity()).load(model.getImage()).error(R.drawable.ic_terrain_black_24dp)
                                        .into(holder.image, new Callback() {
                                            @Override
                                            public void onSuccess() {

                                            }

                                            @Override
                                            public void onError() {
                                                Log.e("ERROR VBK", "COuld not FETCH IMAGE");
                                            }
                                        });


//                               holder.setItemCLickListener(new ItemCLickListener() {
//                                    @Override
//                                    public void onClick(View view, int position) {
//
//
//                                    }
//                                });

                            }
                        }
                );


                holder.imageText.setText(model.getName());
                holder.setItemCLickListener(new ItemCLickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        Common.CATERGORY_ID_SELECTED = adapter.getRef(position).getKey();
                        Common.CATERGORY_SELECTED = model.getName();
                        Intent intent = new Intent(getActivity(), ListActivity.class);
                        startActivity(intent);
                    }
                });


            }

            @Override
            public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

                View itemView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.lay_cat, parent, false);
                return new CategoryViewHolder(itemView);
            }
        };

//        options = new FirebaseRecyclerOptions.Builder <CategoryItem>()
//                .setQuery(mdatabase, CategoryItem.class)
//                .build();
//
//        adapter = new FirebaseRecyclerAdapter<CategoryItem, CategoryViewHolder>(options) {
//            @Override
//            protected void onBindViewHolder(@NonNull final CategoryViewHolder holder, int position, @NonNull final CategoryItem model) {
//                Picasso.with(getActivity()).load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).into(holder
//                                .image, new Callback() {
//                            @Override
//                            public void onSuccess() {
//                                //Picasso.with(getActivity()).load(model.getImage()).error()
//                            }
//
//                            @Override
//                            public void onError() {
//                                Picasso.with(getActivity()).load(model.getImage()).error(R.drawable.ic_terrain_black_24dp)
//                                        .into(holder.image, new Callback() {
//                                            @Override
//                                            public void onSuccess() {
//
//                                            }
//
//                                            @Override
//                                            public void onError() {
//                                                Log.e("ERROR VBK", "COuld not FETCH IMAGE");
//                                            }
//                                        });
//
//
////                               holder.setItemCLickListener(new ItemCLickListener() {
////                                    @Override
////                                    public void onClick(View view, int position) {
////
////
////                                    }
////                                });
//
//                            }
//                        }
//                );
//
//
//                holder.imageText.setText(model.getName());
//                holder.setItemCLickListener(new ItemCLickListener() {
//                    @Override
//                    public void onClick(View view, int position) {
//                        Common.CATERGORY_ID_SELECTED = adapter.getRef(position).getKey();
//                        Common.CATERGORY_SELECTED = model.getName();
//                        Intent intent = new Intent(getActivity(), ListActivity.class);
//                        startActivity(intent);
//                    }
//                });
//
//
//            }
//
//            @Override
//            public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//
//                View itemView = LayoutInflater.from(parent.getContext())
//                        .inflate(R.layout.lay_cat, parent, false);
//                return new CategoryViewHolder(itemView);
//            }
//        };
//


    }
    public static RecentFragment getInstance() {
        if (INSTANCE == null)
            INSTANCE = new RecentFragment();
        return INSTANCE;

    }





    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_recent, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_recent);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);


        recyclerView.setLayoutManager(gridLayoutManager);
        setCategory();


return view;
    }
    private void setCategory() {

        adapter.startListening();
        recyclerView.setAdapter(adapter);

    }

    @Override
    public void onStart() {
        super.onStart();

        if (adapter != null) {
            adapter.startListening();
        }

    }

    @Override
    public void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }


    }




    private void loadRecent() {
        Disposable disposable=recentRepository.getAllRecent()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer <List <Recents>>() {
                    @Override
                    public void accept(List <Recents> recents) throws Exception {
                        onGetAllRecentSucesss(recents);
                    }
                }, new Consumer <Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.d("ERROR",throwable.getMessage());
                    }
                });
        compositeDisposable.add(disposable);


    }

    private void onGetAllRecentSucesss(List<Recents> recents) {

        recentsList.clear();
        recentsList.addAll(recents);
        adapter.notifyDataSetChanged();

    }

    @Override
    public void onDestroy() {
        compositeDisposable.clear();
        super.onDestroy();
    }

    @Override
    public void onDestroyOptionsMenu() {
        super.onDestroyOptionsMenu();
    }
}
