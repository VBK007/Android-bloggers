package nr.king.vbk.wallpaperwide.Fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.karan.churi.PermissionManager.PermissionManager;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import nr.king.vbk.wallpaperwide.Common.Common;
import nr.king.vbk.wallpaperwide.Interface.ItemCLickListener;
import nr.king.vbk.wallpaperwide.ListActivity;
import nr.king.vbk.wallpaperwide.Model.CategoryItem;
import nr.king.vbk.wallpaperwide.R;
import nr.king.vbk.wallpaperwide.ViewHolder.CategoryViewHolder;


public class CategoryFragment extends Fragment {
    RecyclerView recyclerView;
    DatabaseReference mdatabase;
    FirebaseDatabase database;
    FirebaseRecyclerOptions<CategoryItem> options;
    FirebaseRecyclerAdapter<CategoryItem,CategoryViewHolder> adapter;

    public static CategoryFragment INSTANCE=null;
    public CategoryFragment() {
        // Required empty public constructor
        database=FirebaseDatabase.getInstance();
        mdatabase=database.getReference(Common.STR_CATEGORY);

        options=new FirebaseRecyclerOptions.Builder<CategoryItem>()
                .setQuery(mdatabase,CategoryItem.class)
                .build();

        adapter=new FirebaseRecyclerAdapter <CategoryItem, CategoryViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final CategoryViewHolder holder, int position, @NonNull final CategoryItem model) {
                Picasso.with(getActivity()).load(model.getImage()).networkPolicy(NetworkPolicy.OFFLINE).into(holder
                                .image, new Callback() {
                            @Override
                            public void onSuccess() {
                                //Picasso.with(getActivity()).load(model.getImage()).error()
                            }

                            @Override
                            public void onError() {
                                Picasso.with(getActivity()).load(model.getImage()).error(R.drawable.ic_terrain_black_24dp)
                                        .into(holder.image, new Callback() {
                                            @Override
                                            public void onSuccess() {

                                            }

                                            @Override
                                            public void onError() {
                                                Log.e("ERROR VBK","COuld not FETCH IMAGE");
                                            }
                                        });





//                               holder.setItemCLickListener(new ItemCLickListener() {
//                                    @Override
//                                    public void onClick(View view, int position) {
//
//
//                                    }
//                                });

                            }
                        }
                );


                holder.imageText.setText(model.getName());
                holder.setItemCLickListener(new ItemCLickListener() {
                    @Override
                    public void onClick(View view, int position) {
Common.CATERGORY_ID_SELECTED=adapter.getRef(position).getKey();
Common.CATERGORY_SELECTED=model.getName();
                        Intent intent=new Intent(getActivity(), ListActivity.class);
                        startActivity(intent);
                    }
                });


            }

            @Override
            public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

                View itemView=LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.lay_cat,parent,false);
                return new CategoryViewHolder(itemView);
            }
        };



    }

    public static CategoryFragment getInstance(){
        if (INSTANCE==null)
            INSTANCE=new CategoryFragment();
        return INSTANCE;

    }



    public static CategoryFragment newInstance(String param1, String param2) {
        CategoryFragment fragment = new CategoryFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_category, container, false);


        recyclerView=(RecyclerView)view.findViewById(R.id.recycler_category);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(getActivity(),2);

        recyclerView.setLayoutManager(gridLayoutManager);
        PermissionManager permissionManager = new PermissionManager() {
        };
        permissionManager.checkAndRequestPermissions(getActivity());


        setCategory();
        return view;
    }

    private void setCategory() {

        adapter.startListening();
        recyclerView.setAdapter(adapter);

    }

    @Override
    public void onStart() {
        super.onStart();

        if (adapter!=null){
            adapter.startListening();
        }

    }

    @Override
    public void onStop() {
        super.onStop();
        if (adapter!=null){
            adapter.stopListening();
        }


    }

    @Override
    public void onResume() {
        super.onResume();
        if (adapter!=null){
            adapter.startListening();
        }
    }
}
