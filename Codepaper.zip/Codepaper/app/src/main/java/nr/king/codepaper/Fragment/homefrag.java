package nr.king.codepaper.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import nr.king.codepaper.Adapter.CategoryAdapter;
import nr.king.codepaper.Common.Common;
import nr.king.codepaper.Model.Category;
import nr.king.codepaper.R;

public class homefrag extends Fragment {
    FirebaseAuth mAuth;
    FirebaseUser firebaseUser;
    CircleImageView circleImageView;
    TextView username;
    List<Category> categoryList;
    RecyclerView recyclerView;
    CategoryAdapter categoryAdapter;
    FirebaseDatabase firebaseDatabase;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.homefrag,container,false);
        circleImageView=view.findViewById(R.id.userimage);
        username=view.findViewById(R.id.username);
        recyclerView=view.findViewById(R.id.recycle);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager=new GridLayoutManager(getContext(),2);
        //layoutManager.setReverseLayout(true);
        //layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        categoryList=new ArrayList<>();
Collections.reverse(categoryList);

        categoryAdapter=new CategoryAdapter(getContext(),categoryList);
        recyclerView.setAdapter(categoryAdapter);


        loadUserInfo();

        loadCategory();

        return view;
    }

    private void loadCategory() {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Category");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                for (DataSnapshot snapshot:datasnapshot.getChildren())
                {
                    Category post=snapshot.getValue(Category.class);
                    categoryList.add(post);



                }

                categoryAdapter.notifyDataSetChanged();
Collections.reverse(categoryList);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });







    }

    private void loadUserInfo() {
        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        if (FirebaseAuth.getInstance().getCurrentUser()!=null){

            Glide.with(getActivity()).
                    load(FirebaseAuth.getInstance()
                            .getCurrentUser().getPhotoUrl())
                    .into(circleImageView);

if (FirebaseAuth.getInstance().getCurrentUser().getDisplayName()!=null){
    username.setText(FirebaseAuth.getInstance().getCurrentUser().getDisplayName());

}
else {
    username.setText("Codeplays");
}



        }



    }


}
