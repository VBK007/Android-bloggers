package nr.king.codepaper.Fragment;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.Request;
import com.bumptech.glide.request.target.SizeReadyCallback;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.datatransport.runtime.time.WallTimeClock;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import de.hdodenhof.circleimageview.CircleImageView;
import nr.king.codepaper.Adapter.ListAdapter;
import nr.king.codepaper.Adapter.randomwall;
import nr.king.codepaper.Common.Common;
import nr.king.codepaper.Home;
import nr.king.codepaper.Model.List;
import nr.king.codepaper.R;
import nr.king.codepaper.viewwall;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;

public class viewrandi extends Fragment {
public String postid,publisherid,userName,imageUrl;
Fragment fragment;
java.util.List<List> listList;
randomwall listAdapter;
    RecyclerView recyclerView1;
    public  ImageView imageView;
    public ImageView back;
    public ImageView like;
    public TextView likes,username;
    public ImageView save;
public CircleImageView setwall,download;
public CircleImageView userimage;
FirebaseUser firebaseUser;
Button folow;

public Target target=new Target() {
    @Override
    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {

        WallpaperManager wallpaperManager=WallpaperManager.getInstance(getContext());
      try {
          wallpaperManager.setBitmap(bitmap);
          Toast.makeText(getContext(), "Wallpaper was Set Sucessfully", Toast.LENGTH_SHORT).show();
      }
      catch (IOException e){
          e.printStackTrace();
      }


    }

    @Override
    public void onBitmapFailed(Exception e, Drawable errorDrawable) {

    }

    @Override
    public void onPrepareLoad(Drawable placeHolderDrawable) {

    }
};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater
                .inflate(R.layout.activity_viewrandom,container,false);
       SharedPreferences pref=getContext().getSharedPreferences("PREFS", Context.MODE_PRIVATE);
        postid=pref.getString("postid","none");
        publisherid=pref.getString("publisherid","none");
        imageUrl=pref.getString("imageUrl","none");
        userName=pref.getString("userName","none");
        folow=view.findViewById(R.id.follow);
        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
        username=view.findViewById(R.id.username);

       imageView=view.findViewById(R.id.imageview);
        like=view.findViewById(R.id.like);
        likes=view.findViewById(R.id.likes);
        userimage=view.findViewById(R.id.userimage);
        save=view.findViewById(R.id.save);

setwall=view.findViewById(R.id.setwall);


setwall.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        setImage();
    }
});
        isLiked(postid,like);
        nrLikes(postid,likes);
        isSaved(postid,save);

       back=view.findViewById(R.id.back);
        recyclerView1=view.findViewById(R.id.recyclepost);
       back.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               Intent intent=new Intent(getContext(), Home.class);
               startActivity(intent);

           }
       });




        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                if (save.getTag().equals("Save")) {


                    FirebaseDatabase.getInstance().getReference().child("Saved").child(firebaseUser.getUid()).child(postid).setValue(true);
                }
                else{
                    FirebaseDatabase.getInstance().getReference().child("Saved").child(firebaseUser.getUid()).child(postid).removeValue();

                }


            }
        });



        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //favpost();
                nr.king.codepaper.Model.List list=new nr.king.codepaper.Model.List();
                FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                if (like.getTag().equals("Like")) {


                    FirebaseDatabase.getInstance().getReference().child("Likes").child(postid).child(firebaseUser.getUid())
                            .child(postid)
                            .setValue(true);
                }
                else{
                    FirebaseDatabase.getInstance().getReference().child("Likes").child(postid).child(firebaseUser.getUid())
                            .child(postid).removeValue();

                }






            }
        });






        //Toast.makeText(getContext(), ""+ postid, Toast.LENGTH_SHORT).show();

loadImage();
        loadRandom();
        loadUserInfo();


        return view;

    }

    private void loadUserInfo() {


        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Foods").child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List list=snapshot.getValue(List.class);

//

                if (imageUrl!=null){
                    Glide.with(getContext())
                            .load(imageUrl)
                            .into(userimage);
                }


                if (userName!=null){

                    username.setText(userName);
                }

                if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(publisherid)){
                    folow.setVisibility(View.GONE);
                    // Toast.makeText(this, "Equal fuck"+Common.USER_ID, Toast.LENGTH_SHORT).show();
                }
                else{
                    folow.setVisibility(View.VISIBLE);
                    //Toast.makeText(this, "not equal"+Common.USER_ID, Toast.LENGTH_SHORT).show();
                }






            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



















    }

    private void setImage() {

        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Foods").child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List list=snapshot.getValue(List.class);
//                Glide.with(getContext())
//                        .load(list.getImage())
//                        .into(imageView);

//                Picasso.get().load(list.getImage())
//                        .into(imageView);
                Toast.makeText(getContext(), "Please wait...", Toast.LENGTH_LONG).show();

                Picasso.get().load(list.getImage())
                        .into(target);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    private void isSaved(final String list_id, final ImageView save) {
        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Saved")
                .child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(list_id).exists()){

                    save.setImageResource(R.drawable.ic_baseline_bookmark_24 );
                    save.setTag("Saved");


                }

                else {
                    save.setImageResource(R.drawable.ic_baseline_bookmark_border_24);
                    save.setTag("Save");

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void nrLikes(String list_id, final TextView likes) {

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Likes")
                .child(list_id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                likes.setText(snapshot.getChildrenCount()+"Likes");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void isLiked(String list_id, final ImageView like) {

        final FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Likes")
                .child(list_id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(firebaseUser.getUid()).exists()){

                    like.setImageResource(R.drawable.ic_baseline_favorite_24 );
                    like.setTag("Liked");


                }

                else {
                    like.setImageResource(R.drawable.ic_baseline_favorite_border_24);
                    like.setTag("Like");

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






    }





    private void loadImage() {

        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Foods").child(postid);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List list=snapshot.getValue(List.class);
                Glide.with(getContext())
                        .load(list.getImage())
                        .into(imageView);

//                Picasso.get().load(list.getImage())
//                        .into(imageView);
//                Picasso.get().load(list.getImage())
//                        .into(target);



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
    private void loadRandom() {
        recyclerView1.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false));
        recyclerView1.setHasFixedSize(true);
        listList=new ArrayList<>();
        listAdapter=new randomwall(getContext(),listList);
        recyclerView1.setAdapter(listAdapter);

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Foods");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot:snapshot.getChildren())
                {

                    nr.king.codepaper.Model.List post= dataSnapshot.getValue(nr.king.codepaper.Model.List.class);
                    listList.add(post);
                }
                Collections.reverse(listList);
                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });







    }

}
