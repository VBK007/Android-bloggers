package nr.king.codepaper.Common;

import com.google.firebase.auth.FirebaseUser;

import nr.king.codepaper.Model.List;
import nr.king.codepaper.Model.User;

public class Common {
    public static final int SIGN_INREQUEST_CODE =99 ;
    public static final int PICK_IMAGE_REQUEST = 77;
    //public static  USER_NAME = ;
    public static  String USER_NAME;
    public static  String USER_ID;
    public static  String LIST_NAME;
    public static  String LIST_WALLPAER ;
    public static String CATEGORY_NAME ;
    public static  String CATEGORY_ID;
    public static String CATEGORY_ID_SELECTED ;
    public static User curentUser;
public static List select_background=new List();

    public static String List_ID;
    public static String User_IMAGE;
}
