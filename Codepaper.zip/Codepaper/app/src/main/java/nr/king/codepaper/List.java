package nr.king.codepaper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;

import de.hdodenhof.circleimageview.CircleImageView;
import nr.king.codepaper.Adapter.ListAdapter;
import nr.king.codepaper.Common.Common;
import nr.king.codepaper.Fragment.homefrag;

public class List extends AppCompatActivity {


    RecyclerView recyclerView;
    ListAdapter listAdapter;
    java.util.List<nr.king.codepaper.Model.List> listList;
    CircleImageView circleImageView;
    ImageView selectimage;
    StorageReference storageReference;
    Uri saveuri;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        TextView textView=findViewById(R.id.category);
        textView.setText(Common.CATEGORY_NAME);
storageReference= FirebaseStorage.getInstance().getReference("Posts");
        //Toast.makeText(this, ""+Common.CATEGORY_ID_SELECTED, Toast.LENGTH_SHORT).show();

        circleImageView =findViewById(R.id.addimage);
        circleImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadImage();
            }
        });


        ImageView imageView=findViewById(R.id.back);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(List.this, Home.class);
                startActivity(intent);


            }
        });


        recyclerView=findViewById(R.id.recycle);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getApplicationContext(),2);
        recyclerView.setLayoutManager(layoutManager);
        listList=new ArrayList<>();
        listAdapter=new ListAdapter(getApplicationContext(),listList);

        recyclerView.setHasFixedSize(true);

        recyclerView.setAdapter(listAdapter);

        loadList();





    }

    private void uploadImage() {

        AlertDialog.Builder imagedailog=new AlertDialog.Builder(this);
        imagedailog.setTitle("Please Select Image to Upload!!");
        LayoutInflater inflater=this.getLayoutInflater();
        View view=inflater.inflate(R.layout.uploadimage,null);
        imagedailog.setView(view);
        selectimage=view.findViewById(R.id.selectimage);
        final TextView name=view.findViewById(R.id.editname);
        final TextView desc=view.findViewById(R.id.edtdesc);


        selectimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();
            }
        });

        imagedailog.setPositiveButton("Upload", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                if (TextUtils.isEmpty(name.getText().toString()) && TextUtils.isEmpty(desc.getText().toString())){
                    Toast.makeText(List.this, "Please fill Name ", Toast.LENGTH_SHORT).show();
                    dialogInterface.dismiss();

                }
                else{

                    if (saveuri!=null){

                        final ProgressDialog progressDialog=new ProgressDialog(List.this);
                        progressDialog.setMessage("Please wait....");
                        progressDialog.show();


                        String imagename= UUID.randomUUID().toString();
                        final StorageReference reference=storageReference.child("Image"+imagename);
                        reference.putFile(saveuri)
                                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                    @Override
                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                                        reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                            @Override
                                            public void onSuccess(Uri uri) {

                                                DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Foods");
                                                DatabaseReference reference1=FirebaseDatabase.getInstance().getReference("New");
FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

                                                String postid = reference.push().getKey();
Uri uri1=firebaseUser.getPhotoUrl();
                                                HashMap<String, Object> hashMap = new HashMap<>();
                                                hashMap.put("postid", postid);
                                                hashMap.put("menuId",Common.CATEGORY_ID_SELECTED);
                                                hashMap.put("image", uri.toString());
                                                hashMap.put("userName",firebaseUser.getDisplayName());
                                                hashMap.put("description", desc.getText().toString().toLowerCase());
                                                hashMap.put("name",name.getText().toString().toLowerCase());
                                                hashMap.put("imageUrl",uri1.toString());
                                                hashMap.put("publisherid", FirebaseAuth.getInstance().getCurrentUser().getUid());

                                                reference.child(postid).setValue(hashMap);


                                                HashMap<String ,Object> hashMap1=new HashMap<>();
                                                hashMap1.put("postid",postid);
                                                reference1.child(postid).setValue(hashMap1);





                                                progressDialog.dismiss();





                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                progressDialog.dismiss();

                                            }
                                        });



                                    }
                                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {

                            }
                        });







                    }


                }














            }
        });


        imagedailog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
dialogInterface.dismiss();





            }
        });

imagedailog.show();



    }

    private void chooseImage() {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Picture"),Common.PICK_IMAGE_REQUEST);





    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode==Common.PICK_IMAGE_REQUEST && resultCode==RESULT_OK&& data!=null && data.getData()!=null){

             saveuri=data.getData();
            if (saveuri!=null){
                selectimage.setImageURI(saveuri);

            }
        }
    }

    private void loadList() {

        Query reference= FirebaseDatabase.getInstance().getReference("Foods").orderByChild("menuId").equalTo(Common.CATEGORY_ID_SELECTED);


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot:snapshot.getChildren()){

                    nr.king.codepaper.Model.List post=dataSnapshot.getValue(nr.king.codepaper.Model.List.class);
                   listList.add(post);

                }
                Collections.reverse(listList);
                listAdapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    @Override
    protected void onStop() {
        listAdapter.notifyDataSetChanged();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        listAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        listAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
        listAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        listAdapter.notifyDataSetChanged();
    }
}