package nr.king.codepaper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import de.hdodenhof.circleimageview.CircleImageView;
import nr.king.codepaper.Common.Common;
import nr.king.codepaper.Fragment.explore;
import nr.king.codepaper.Fragment.favorite;
import nr.king.codepaper.Fragment.homefrag;
import nr.king.codepaper.Fragment.userhome;

public class Home extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
FirebaseAuth mauth;
FirebaseUser firebaseUser;
private CircleImageView circleImageView;
private TextView txtUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        loadFragment(new homefrag());
     BottomNavigationView   bottomNavigationView=findViewById(R.id.botview);

        bottomNavigationView.setOnNavigationItemSelectedListener(this);


        if (FirebaseAuth.getInstance().getCurrentUser()==null){
           startActivityForResult(AuthUI.getInstance().createSignInIntentBuilder().setIsSmartLockEnabled(false).build(),Common.SIGN_INREQUEST_CODE);


        }
        else{


            loadUserInfo();

        }


    }

    private boolean loadFragment(Fragment fragment) {


      if (fragment!=null){
          getSupportFragmentManager().beginTransaction().replace(R.id.fralay,fragment).commit();
          return true;
      }
       return false;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode==Common.SIGN_INREQUEST_CODE && resultCode==RESULT_OK){

//startActivityForResult(AuthUI.getInstance().createSignInIntentBuilder().setIsSmartLockEnabled(false).build(),Common.SIGN_INREQUEST_CODE);

        }
    }

    private void loadUserInfo() {

       // Toast.makeText(this, ""+FirebaseAuth.getInstance().getCurrentUser().getDisplayName(), Toast.LENGTH_LONG).show();



    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment fragment=null;
        switch (item.getItemId()){
            case R.id.home:
                fragment=new homefrag();
                break;


            case R.id.explore:
                fragment=new explore();
                break;


            case R.id.favorite:
                fragment=new favorite();
                break;

            case R.id.user:
                fragment=new userhome();
                break;




        }


        return loadFragment(fragment);
    }
}