package nr.king.codepaper.Model;

public class Menu {

    private String MenuId;


    public Menu() {
    }

    public Menu(String menuId) {
        MenuId = menuId;
    }

    public String getMenuId() {
        return MenuId;
    }

    public void setMenuId(String menuId) {
        MenuId = menuId;
    }
}
