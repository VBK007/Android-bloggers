package nr.king.codepaper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import nr.king.codepaper.Adapter.randomwall;
import nr.king.codepaper.Adapter.viewwalladapter;
import nr.king.codepaper.Common.Common;

public class viewwall extends AppCompatActivity {
ImageView imageView;
ImageView back,like;
CircleImageView circleImageView;
List<nr.king.codepaper.Model.List> listList;
randomwall listAdapter;
viewwalladapter viewwalladapter;
RecyclerView recyclerView;
TextView likes,username;
ImageView save;
CircleImageView userimage;
Button folow;

public Target target=new Target() {
    @Override
    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
        WallpaperManager wallpaperManager=WallpaperManager.getInstance(getApplicationContext());
        try {
            wallpaperManager.setBitmap(bitmap);
            Toast.makeText(viewwall.this, "Wallpaer set Sucessfully", Toast.LENGTH_SHORT).show();
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void onBitmapFailed(Exception e, Drawable errorDrawable) {

    }

    @Override
    public void onPrepareLoad(Drawable placeHolderDrawable) {

    }
};
    FirebaseUser firebaseUser;
CircleImageView setwall,download;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewwall);

      imageView=findViewById(R.id.imageview);
        Glide.with(this).load(Common.LIST_WALLPAER)
                .into(imageView);

       // Toast.makeText(this, ""+Common.List_ID, Toast.LENGTH_SHORT).show();
        like=findViewById(R.id.like);
likes=findViewById(R.id.likes);
save=findViewById(R.id.save);
setwall=findViewById(R.id.setwall);
userimage=findViewById(R.id.userimage);
folow=findViewById(R.id.follow);
        username=findViewById(R.id.username);
         firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
if (Common.User_IMAGE!=null){
    Glide.with(getApplicationContext())
            .load(Common.User_IMAGE)
            .into(userimage);
}

else{
    userimage.setImageResource(R.mipmap.ic_launcher);
}


if (Common.USER_NAME!=null){

    username.setText(Common.USER_NAME);
}
else {
    username.setText("Codeplays");
}

if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(Common.USER_ID)){
  folow.setVisibility(View.GONE);
   // Toast.makeText(this, "Equal fuck"+Common.USER_ID, Toast.LENGTH_SHORT).show();
}
else{
  folow.setVisibility(View.VISIBLE);
    //Toast.makeText(this, "not equal"+Common.USER_ID, Toast.LENGTH_SHORT).show();
}


isFollowing(Common.USER_ID,folow);


folow.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if (folow.getText().toString().equals("follow")){

            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                    .child("following").child(Common.USER_ID).setValue(true);

            FirebaseDatabase.getInstance().getReference().child("Follow").child(Common.USER_ID)
                    .child("followers").child(firebaseUser.getUid()).setValue(true);


           // addNotifications(user.getId());

        }
        else{


            FirebaseDatabase.getInstance().getReference().child("Follow").child(firebaseUser.getUid())
                    .child("following").child(Common.USER_ID).removeValue();

            FirebaseDatabase.getInstance().getReference().child("Follow").child(Common.USER_ID)
                    .child("followers").child(firebaseUser.getUid()).removeValue();



        }



    }
});









setwall.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Toast.makeText(viewwall.this, "Please wait...", Toast.LENGTH_LONG).show();

        Picasso.get().load(Common.LIST_WALLPAER)
                .into(target);
    }
});




isLiked(Common.List_ID,like);
nrLikes(Common.List_ID,likes);
isSaved(Common.List_ID,save);

        back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(viewwall.this, nr.king.codepaper.List.class);
                startActivity(intent);
            }
        });





save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

        FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
        if (save.getTag().equals("Save")) {


            FirebaseDatabase.getInstance().getReference().child("Saved").child(firebaseUser.getUid()).child(Common.List_ID).setValue(true);
        }
        else{
            FirebaseDatabase.getInstance().getReference().child("Saved").child(firebaseUser.getUid()).child(Common.List_ID).removeValue();

        }


    }
});



like.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        //favpost();
        nr.king.codepaper.Model.List list=new nr.king.codepaper.Model.List();
        FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
if (like.getTag().equals("Like")) {


    FirebaseDatabase.getInstance().getReference().child("Likes").child(Common.List_ID).child(firebaseUser.getUid())
            .child(Common.List_ID)
            .setValue(true);
}
        else{
            FirebaseDatabase.getInstance().getReference().child("Likes").child(Common.List_ID).child(firebaseUser.getUid())
                    .child(Common.List_ID).removeValue();

        }






        }
});




















       // Toast.makeText(this, ""+Common.CATEGORY_ID_SELECTED, Toast.LENGTH_SHORT).show();

       // loadPost();

       loadRandom();











    }

    private void isFollowing(final String userId, final Button folow) {

        DatabaseReference reference= FirebaseDatabase.getInstance().getReference()
                .child("Follow").child(firebaseUser.getUid()).child("following");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(userId).exists()){
                    folow.setText("following");

                }
                else{
                    folow.setText("follow");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




    }

//    private void setImage() {
//
////        Glide.with(this).load(Common.LIST_WALLPAER)
////                .into(imageView);
//
//
//
//    }

    private void isSaved(final String list_id, final ImageView save) {
        final FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Saved")
                .child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(list_id).exists()){

                    save.setImageResource(R.drawable.ic_baseline_bookmark_24 );
                    save.setTag("Saved");


                }

                else {
                    save.setImageResource(R.drawable.ic_baseline_bookmark_border_24);
                    save.setTag("Save");

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void nrLikes(String list_id, final TextView likes) {

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Likes")
                .child(list_id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                likes.setText(snapshot.getChildrenCount()+"Likes");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void isLiked(String list_id, final ImageView like) {

        final FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("Likes")
                .child(list_id);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.child(firebaseUser.getUid()).exists()){

                    like.setImageResource(R.drawable.ic_baseline_favorite_24 );
                    like.setTag("Liked");


                }

                else {
                    like.setImageResource(R.drawable.ic_baseline_favorite_border_24);
                    like.setTag("Like");

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






    }

    private void favpost() {

        final DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Likes");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
String postid=reference.push().getKey();
HashMap<String,Object> hashMap=new HashMap<>();
hashMap.put("postid",postid);
hashMap.put("uid",firebaseUser.getUid());






            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    private void loadPost() {
        recyclerView=findViewById(R.id.recycle);

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setHasFixedSize(true);

        listList=new ArrayList<>();

        viewwalladapter=new viewwalladapter(getApplicationContext(),listList);
        recyclerView.setAdapter(viewwalladapter);


        Query reference= FirebaseDatabase.getInstance().getReference("Foods")
                .orderByChild("menuId").equalTo(Common.CATEGORY_ID_SELECTED);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot:snapshot.getChildren()){

                    nr.king.codepaper.Model.List post= dataSnapshot.getValue(nr.king.codepaper.Model.List.class);
                    listList.add(post);


                }
                viewwalladapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void loadRandom() {

        RecyclerView recyclerView1=findViewById(R.id.recyclepost);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerView1.setHasFixedSize(true);
listList=new ArrayList<>();
listAdapter=new randomwall(getApplicationContext(),listList);
recyclerView1.setAdapter(listAdapter);

        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Foods");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot:snapshot.getChildren())
                {

                    nr.king.codepaper.Model.List post= dataSnapshot.getValue(nr.king.codepaper.Model.List.class);
                    listList.add(post);
                }

                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });







    }


}